using James_Fowler_CPT206_Lab5.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace James_Fowler_CPT206_Lab5.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHttpClientFactory _clientFactory;

        public HomeController(ILogger<HomeController> logger,
            IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _clientFactory = httpClientFactory;
        }

        public IActionResult Index()
        {
            return View();
        }

        
        public async Task<IActionResult> Students()
        {
            ViewData["Title"] = "All Students";
            var client = _clientFactory.CreateClient("StudentProfileWebApi");
            var response = await client.GetAsync("api/StudentProfiles");

            if (response.IsSuccessStatusCode)
            {
                var students = await response.Content.ReadFromJsonAsync<IEnumerable<Student>>();
                return View(students);
            }
            else
            {
                return Content("Failed to fetch data from the API");
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
